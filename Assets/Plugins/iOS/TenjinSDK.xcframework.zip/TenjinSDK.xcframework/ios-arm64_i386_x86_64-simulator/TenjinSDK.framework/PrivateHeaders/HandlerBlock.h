
// Created by Tenjin on 2019-09-17.
// Copyright (c) 2019 Tenjin. All rights reserved.


#import <Foundation/Foundation.h>

typedef void (^HandlerBlock)(NSData *_Nullable data, NSURLResponse *_Nullable NSURLResponse, NSError *_Nullable error, BOOL retry);
